#!/bin/bash
# Questo è un commento
chmod 777 flash.sh

