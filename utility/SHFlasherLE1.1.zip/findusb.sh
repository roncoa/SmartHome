#!/bin/bash
# Questo è un commento
echo -n "/dev/"; dmesg | grep tty|grep USB|rev|awk '{print $1}'|rev > usbdata.tmp

