#!/bin/bash
cd esptool
sudo esptool.py --port /dev/ttyUSB0 read_flash 0x00000 0x400000 pippofranco4MB.bin
