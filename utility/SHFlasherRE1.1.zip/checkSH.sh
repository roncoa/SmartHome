#!/bin/bash
# if [ -f SmartHome*.zip ]; then
while  [ -f SmartHome*.zip ]
 do  
    echo "Trovata file SmartHome"
    echo "Decompressione file in corso"
    unzip SmartH*.zip
    mv *.bin esptool
    rm -f SmartH*.zip
    exit
done
#else
    echo "Il file non esiste!"
#fi
exit

