#!/bin/bash
# Questo è un commento
git clone https://github.com/themadinventor/esptool.git
cd esptool
sudo apt-get install python3-setuptools
sudo python3 setup.py install 
exit

